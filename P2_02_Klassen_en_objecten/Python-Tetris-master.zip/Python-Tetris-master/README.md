# Python-Tetris
Tetris using Python and Pygame

![tetris](screenshot/1.png "Tetris")
