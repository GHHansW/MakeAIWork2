from circle import Circle

circle = Circle(4)
print(f"The area of the triangle is : {circle.area()}")
