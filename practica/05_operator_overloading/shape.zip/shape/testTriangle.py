#!/usr/bin/env python

from triangle import Triangle

triangle = Triangle(4, 5)
print(f"The area of the triangle is : {triangle.area()}")
